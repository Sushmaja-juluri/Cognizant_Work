const mongoose = require('mongoose');

const ActivitySchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Please add an activity name']
  },
  description: {
    type: String
  },
  location: {
    type: String,
    required: [true, 'Please add a location']
  },
  date: {
    type: Date,
    required: [true, 'Please add a date']
  },
  startTime: {
    type: String
  },
  endTime: {
    type: String
  },
  cost: {
    type: Number,
    default: 0
  },
  trip: {
    type: mongoose.Schema.ObjectId,
    ref: 'Trip',
    required: true
  },
  votes: [{
    user: {
      type: mongoose.Schema.ObjectId,
      ref: 'User'
    },
    vote: {
      type: String,
      enum: ['yes', 'no', 'maybe']
    }
  }],
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Activity', ActivitySchema);