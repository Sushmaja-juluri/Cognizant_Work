const mongoose = require('mongoose');

const ExpenseSchema = new mongoose.Schema({
  description: {
    type: String,
    required: [true, 'Please add a description']
  },
  amount: {
    type: Number,
    required: [true, 'Please add an amount']
  },
  paidBy: {
    type: mongoose.Schema.ObjectId,
    ref: 'User',
    required: true
  },
  trip: {
    type: mongoose.Schema.ObjectId,
    ref: 'Trip',
    required: true
  },
  splitBetween: [{
    user: {
      type: mongoose.Schema.ObjectId,
      ref: 'User'
    },
    amount: Number,
    settled: {
      type: Boolean,
      default: false
    }
  }],
  category: {
    type: String,
    enum: ['transportation', 'accommodation', 'food', 'activities', 'shopping', 'other'],
    default: 'other'
  },
  date: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Expense', ExpenseSchema);