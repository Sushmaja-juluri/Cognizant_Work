const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const auth = require('../middleware/auth');
const Expense = require('../models/Expense');
const Trip = require('../models/Trip');
const User = require('../models/User');

// @route    POST api/v1/expenses
// @desc     Add an expense to a trip
// @access   Private
router.post(
  '/',
  [
    auth,
    [
      check('description', 'Description is required').not().isEmpty().trim().escape(),
      check('amount', 'Amount must be a positive number').isFloat({ min: 0.01 }),
      check('trip', 'Trip ID is required').isMongoId(),
      check('category', 'Category is required').not().isEmpty().trim().escape(),
      check('splitBetween', 'Split information is required').isArray({ min: 1 }),
      check('splitBetween.*.user', 'User ID is required').isMongoId(),
      check('splitBetween.*.share', 'Share must be a positive number').isFloat({ min: 0 })
    ]
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { description, amount, trip, category, splitBetween } = req.body;

    try {
      // Verify trip exists and user is a member
      const tripDoc = await Trip.findById(trip);
      if (!tripDoc) {
        return res.status(404).json({ msg: 'Trip not found' });
      }

      const isMember = tripDoc.members.some(
        member => member.user.toString() === req.user.id
      );

      if (!isMember) {
        return res.status(403).json({ msg: 'Not authorized to add expenses to this trip' });
      }

      // Validate splitBetween users and calculate total shares
      let totalShares = 0;
      const memberIds = tripDoc.members.map(m => m.user.toString());
      
      for (const split of splitBetween) {
        if (!memberIds.includes(split.user)) {
          return res.status(400).json({ 
            msg: `User ${split.user} is not a trip member` 
          });
        }
        totalShares += parseFloat(split.share || 0);
      }

      // Validate shares match the amount (with tolerance for floating point)
      if (Math.abs(totalShares - amount) > 0.01) {
        return res.status(400).json({ 
          msg: 'Total shares must equal the expense amount' 
        });
      }

      // Create new expense
      const expense = new Expense({
        description,
        amount,
        paidBy: req.user.id,
        trip,
        category: category.toLowerCase(),
        splitBetween: splitBetween.map(split => ({
          user: split.user,
          share: split.share,
          settled: false
        }))
      });

      await expense.save();

      // Add expense to trip
      tripDoc.expenses.push(expense._id);
      await tripDoc.save();

      // Populate user details in response
      const populatedExpense = await Expense.findById(expense._id)
        .populate('paidBy', 'name email avatar')
        .populate('splitBetween.user', 'name email avatar');

      res.status(201).json(populatedExpense);
    } catch (err) {
      console.error(err.message);
      res.status(500).json({ msg: 'Server error' });
    }
  }
);

// @route    GET api/v1/expenses/trip/:tripId
// @desc     Get all expenses for a trip
// @access   Private
router.get('/trip/:tripId', [
  auth,
  check('tripId', 'Invalid trip ID').isMongoId()
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const trip = await Trip.findById(req.params.tripId);
    if (!trip) {
      return res.status(404).json({ msg: 'Trip not found' });
    }

    // Check authorization
    const isMember = trip.members.some(
      member => member.user.toString() === req.user.id
    );
    if (!isMember) {
      return res.status(403).json({ msg: 'Not authorized to view these expenses' });
    }

    const expenses = await Expense.find({ trip: req.params.tripId })
      .populate('paidBy', 'name email avatar')
      .populate('splitBetween.user', 'name email avatar')
      .sort({ createdAt: -1 });

    res.json(expenses);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
});

// @route    PUT api/v1/expenses/:id/settle
// @desc     Mark an expense split as settled
// @access   Private
router.put('/:id/settle', [
  auth,
  check('id', 'Invalid expense ID').isMongoId()
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const expense = await Expense.findById(req.params.id);
    if (!expense) {
      return res.status(404).json({ msg: 'Expense not found' });
    }

    // Check if user is part of the split
    const userSplit = expense.splitBetween.find(
      split => split.user.toString() === req.user.id
    );
    if (!userSplit) {
      return res.status(403).json({ msg: 'Not authorized to settle this expense' });
    }

    // Update settled status
    userSplit.settled = true;
    
    // Check if all splits are now settled
    const allSettled = expense.splitBetween.every(split => split.settled);
    if (allSettled) {
      expense.fullySettled = true;
    }

    await expense.save();

    // Return populated expense
    const populatedExpense = await Expense.findById(expense._id)
      .populate('paidBy', 'name email avatar')
      .populate('splitBetween.user', 'name email avatar');

    res.json(populatedExpense);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
});

// @route    DELETE api/v1/expenses/:id
// @desc     Delete an expense
// @access   Private (only expense creator or trip admin)
router.delete('/:id', [
  auth,
  check('id', 'Invalid expense ID').isMongoId()
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const expense = await Expense.findById(req.params.id);
    if (!expense) {
      return res.status(404).json({ msg: 'Expense not found' });
    }

    // Check if user is the payer or trip admin
    const trip = await Trip.findById(expense.trip);
    const isPayer = expense.paidBy.toString() === req.user.id;
    const isAdmin = trip.members.some(
      member => member.user.toString() === req.user.id && member.role === 'admin'
    );

    if (!isPayer && !isAdmin) {
      return res.status(403).json({ msg: 'Not authorized to delete this expense' });
    }

    // Remove expense from trip
    await Trip.findByIdAndUpdate(expense.trip, {
      $pull: { expenses: expense._id }
    });

    // Delete expense
    await expense.remove();

    res.json({ msg: 'Expense removed' });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
});

module.exports = router;