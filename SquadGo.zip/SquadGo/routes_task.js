const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const auth = require('../middleware/auth');
const Task = require('../models/Task');
const Trip = require('../models/Trip');
const User = require('../models/User');

// @route    POST api/v1/tasks
// @desc     Add a task to a trip
// @access   Private
router.post(
  '/',
  [
    auth,
    [
      check('title', 'Title is required').not().isEmpty(),
      check('assignedTo', 'Assigned user is required').not().isEmpty(),
      check('trip', 'Trip ID is required').not().isEmpty()
    ]
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { title, description, assignedTo, trip, dueDate, priority } = req.body;

    try {
      // Check if trip exists and user is a member
      const tripDoc = await Trip.findById(trip);
      if (!tripDoc) {
        return res.status(404).json({ msg: 'Trip not found' });
      }

      const isMember = tripDoc.members.some(
        member => member.user.toString() === req.user.id
      );

      if (!isMember) {
        return res.status(401).json({ msg: 'Not authorized to add tasks to this trip' });
      }

      // Check if assigned user is a trip member
      const isAssignedMember = tripDoc.members.some(
        member => member.user.toString() === assignedTo
      );

      if (!isAssignedMember) {
        return res.status(400).json({ msg: 'Assigned user is not a trip member' });
      }

      const task = new Task({
        title,
        description,
        assignedTo,
        trip,
        dueDate,
        priority
      });

      await task.save();

      // Add task to trip
      await Trip.findByIdAndUpdate(trip, {
        $push: { tasks: task._id }
      });

      res.json(task);
    } catch (err) {
      console.error(err.message);
      res.status(500).send('Server error');
    }
  }
);

// @route    GET api/v1/tasks/trip/:tripId
// @desc     Get all tasks for a trip
// @access   Private
router.get('/trip/:tripId', auth, async (req, res) => {
  try {
    const trip = await Trip.findById(req.params.tripId);

    if (!trip) {
      return res.status(404).json({ msg: 'Trip not found' });
    }

    // Check if user is a member
    const isMember = trip.members.some(
      member => member.user.toString() === req.user.id
    );

    if (!isMember) {
      return res.status(401).json({ msg: 'Not authorized to view tasks for this trip' });
    }

    const tasks = await Task.find({ trip: req.params.tripId })
      .populate('assignedTo', 'name email')
      .sort({ dueDate: 1, priority: -1 });

    res.json(tasks);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Trip not found' });
    }
    res.status(500).send('Server error');
  }
});

// @route    PUT api/v1/tasks/:id/complete
// @desc     Mark a task as completed
// @access   Private
router.put('/:id/complete', auth, async (req, res) => {
  try {
    const task = await Task.findById(req.params.id);

    if (!task) {
      return res.status(404).json({ msg: 'Task not found' });
    }

    // Check if user is the assigned user
    if (task.assignedTo.toString() !== req.user.id) {
      return res.status(401).json({ msg: 'Not authorized to complete this task' });
    }

    task.completed = true;
    await task.save();

    res.json(task);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Task not found' });
    }
    res.status(500).send('Server error');
  }
});

module.exports = router;