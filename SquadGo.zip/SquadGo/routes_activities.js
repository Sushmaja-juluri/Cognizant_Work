const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const auth = require('../middleware/auth');
const Activity = require('../models/Activity');
const Trip = require('../models/Trip');

// @route    POST api/v1/activities
// @desc     Add an activity to a trip
// @access   Private
router.post(
  '/',
  [
    auth,
    [
      check('name', 'Activity name is required').not().isEmpty(),
      check('location', 'Location is required').not().isEmpty(),
      check('date', 'Date is required').not().isEmpty(),
      check('trip', 'Trip ID is required').not().isEmpty()
    ]
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { name, description, location, date, startTime, endTime, cost, trip } = req.body;

    try {
      // Check if trip exists and user is a member
      const tripDoc = await Trip.findById(trip);
      if (!tripDoc) {
        return res.status(404).json({ msg: 'Trip not found' });
      }

      const isMember = tripDoc.members.some(
        member => member.user.toString() === req.user.id
      );

      if (!isMember) {
        return res.status(401).json({ msg: 'Not authorized to add activities to this trip' });
      }

      const activity = new Activity({
        name,
        description,
        location,
        date,
        startTime,
        endTime,
        cost,
        trip
      });

      await activity.save();

      // Add activity to trip
      await Trip.findByIdAndUpdate(trip, {
        $push: { activities: activity._id }
      });

      res.json(activity);
    } catch (err) {
      console.error(err.message);
      res.status(500).send('Server error');
    }
  }
);

// @route    GET api/v1/activities/trip/:tripId
// @desc     Get all activities for a trip
// @access   Private
router.get('/trip/:tripId', auth, async (req, res) => {
  try {
    const trip = await Trip.findById(req.params.tripId);

    if (!trip) {
      return res.status(404).json({ msg: 'Trip not found' });
    }

    // Check if user is a member
    const isMember = trip.members.some(
      member => member.user.toString() === req.user.id
    );

    if (!isMember) {
      return res.status(401).json({ msg: 'Not authorized to view activities for this trip' });
    }

    const activities = await Activity.find({ trip: req.params.tripId })
      .sort({ date: 1, startTime: 1 });

    res.json(activities);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Trip not found' });
    }
    res.status(500).send('Server error');
  }
});

// @route    PUT api/v1/activities/:id/vote
// @desc     Vote on an activity
// @access   Private
router.put('/:id/vote', auth, async (req, res) => {
  const { vote } = req.body;

  try {
    const activity = await Activity.findById(req.params.id);

    if (!activity) {
      return res.status(404).json({ msg: 'Activity not found' });
    }

    // Check if user is a trip member
    const trip = await Trip.findById(activity.trip);
    const isMember = trip.members.some(
      member => member.user.toString() === req.user.id
    );

    if (!isMember) {
      return res.status(401).json({ msg: 'Not authorized to vote on this activity' });
    }

    // Check if user already voted
    const existingVoteIndex = activity.votes.findIndex(
      v => v.user.toString() === req.user.id
    );

    if (existingVoteIndex !== -1) {
      // Update existing vote
      activity.votes[existingVoteIndex].vote = vote;
    } else {
      // Add new vote
      activity.votes.push({
        user: req.user.id,
        vote
      });
    }

    await activity.save();

    res.json(activity);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Activity not found' });
    }
    res.status(500).send('Server error');
  }
});

module.exports = router;