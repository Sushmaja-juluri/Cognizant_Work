// DOM Elements
const loginBtn = document.getElementById('login-btn');
const getStartedBtn = document.getElementById('get-started-btn');
const loginModal = document.getElementById('login-modal');
const registerModal = document.getElementById('register-modal');
const tripModal = document.getElementById('trip-modal');
const closeModalBtns = document.querySelectorAll('.close-modal, .close-modal-btn');
const switchToRegister = document.getElementById('switch-to-register');
const switchToLogin = document.getElementById('login-link');
const viewTripBtn = document.getElementById('view-trip-btn');
const printConfirmationBtn = document.getElementById('print-confirmation');

// Initialize date pickers
const startDatePicker = flatpickr("#trip-start-date", {
    minDate: "today",
    dateFormat: "Y-m-d",
    onChange: function(selectedDates, dateStr) {
        endDatePicker.set("minDate", dateStr);
    }
});

const endDatePicker = flatpickr("#trip-end-date", {
    minDate: "today",
    dateFormat: "Y-m-d"
});

// Modal functionality
function openModal(modal) {
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeModal(modal) {
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Event Listeners
loginBtn.addEventListener('click', () => openModal(loginModal));
getStartedBtn.addEventListener('click', () => openModal(tripModal));
switchToRegister.addEventListener('click', (e) => {
    e.preventDefault();
    closeModal(loginModal);
    openModal(registerModal);
});

closeModalBtns.forEach(btn => {
    btn.addEventListener('click', function() {
        const modal = this.closest('.modal');
        closeModal(modal);
        
        // Reset trip form if closing trip modal
        if (modal.id === 'trip-modal') {
            resetTripForm();
        }
    });
});

// Close modal when clicking outside
window.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal')) {
        closeModal(e.target);
        
        // Reset trip form if closing trip modal
        if (e.target.id === 'trip-modal') {
            resetTripForm();
        }
    }
});

// Payment method selection
const paymentMethods = document.querySelectorAll('.payment-method');
const paymentForms = document.querySelectorAll('.payment-form');

paymentMethods.forEach(method => {
    method.addEventListener('click', function() {
        // Remove active class from all methods
        paymentMethods.forEach(m => m.classList.remove('active'));
        // Add active class to clicked method
        this.classList.add('active');
        
        // Hide all payment forms
        paymentForms.forEach(form => form.style.display = 'none');
        
        // Show selected payment form
        const methodType = this.getAttribute('data-method');
        document.getElementById(${methodType}-form).style.display = 'block';
    });
});

// Format credit card inputs
document.getElementById('card-number').addEventListener('input', function(e) {
    let value = e.target.value.replace(/\s+/g, '');
    if (value.length > 0) {
        value = value.match(new RegExp('.{1,4}', 'g')).join(' ');
    }
    e.target.value = value;
});

document.getElementById('card-expiry').addEventListener('input', function(e) {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 2) {
        value = value.substring(0, 2) + '/' + value.substring(2, 4);
    }
    e.target.value = value;
});

// Form validation
function validateForm(formId) {
    let isValid = true;
    const form = document.getElementById(formId);
    const inputs = form.querySelectorAll('input[required], select[required], textarea[required]');
    
    inputs.forEach(input => {
        const errorId = ${input.id}-error;
        const errorElement = document.getElementById(errorId);
        
        if (!input.value) {
            input.classList.add('has-error');
            errorElement.textContent = 'This field is required';
            errorElement.style.display = 'block';
            isValid = false;
        } else {
            input.classList.remove('has-error');
            errorElement.style.display = 'none';
            
            // Additional validation for specific fields
            if (input.id === 'register-email' || input.id === 'login-email') {
                if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value)) {
                    input.classList.add('has-error');
                    errorElement.textContent = 'Please enter a valid email';
                    errorElement.style.display = 'block';
                    isValid = false;
                }
            }
            
            if (input.id === 'register-password') {
                if (input.value.length < 8) {
                    input.classList.add('has-error');
                    errorElement.textContent = 'Password must be at least 8 characters';
                    errorElement.style.display = 'block';
                    isValid = false;
                }
            }
            
            if (input.id === 'register-confirm-password') {
                const password = document.getElementById('register-password').value;
                if (input.value !== password) {
                    input.classList.add('has-error');
                    errorElement.textContent = 'Passwords do not match';
                    errorElement.style.display = 'block';
                    isValid = false;
                }
            }
            
            if (input.id === 'card-number') {
                if (!/^\d{4}\s\d{4}\s\d{4}\s\d{4}$/.test(input.value)) {
                    input.classList.add('has-error');
                    errorElement.textContent = 'Please enter a valid card number';
                    errorElement.style.display = 'block';
                    isValid = false;
                }
            }
            
            if (input.id === 'card-expiry') {
                if (!/^\d{2}\/\d{2}$/.test(input.value)) {
                    input.classList.add('has-error');
                    errorElement.textContent = 'Please enter a valid expiry date (MM/YY)';
                    errorElement.style.display = 'block';
                    isValid = false;
                }
            }
            
            if (input.id === 'card-cvc') {
                if (!/^\d{3,4}$/.test(input.value)) {
                    input.classList.add('has-error');
                    errorElement.textContent = 'Please enter a valid CVC';
                    errorElement.style.display = 'block';
                    isValid = false;
                }
            }
        }
    });
    
    // Validate date range
    if (formId === 'trip-form') {
        const startDate = new Date(document.getElementById('trip-start-date').value);
        const endDate = new Date(document.getElementById('trip-end-date').value);
        
        if (startDate && endDate && startDate > endDate) {
            document.getElementById('trip-end-date-error').textContent = 'End date must be after start date';
            document.getElementById('trip-end-date-error').style.display = 'block';
            document.getElementById('trip-end-date').classList.add('has-error');
            isValid = false;
        }
    }
    
    return isValid;
}

// Form submissions
document.getElementById('login-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    if (!validateForm('login-form')) return;
    
    // Show loading spinner
    const submitBtn = this.querySelector('button[type="submit"]');
    const spinner = submitBtn.querySelector('.spinner');
    const buttonText = submitBtn.querySelector('.button-text');
    
    buttonText.style.display = 'none';
    spinner.style.display = 'block';
    
    // Simulate API call
    setTimeout(() => {
        // Hide loading spinner
        buttonText.style.display = 'inline';
        spinner.style.display = 'none';
        
        // Close modal
        closeModal(loginModal);
        
        // Show success message (in a real app, you'd handle the login response)
        alert('Login successful!');
    }, 1500);
});

document.getElementById('register-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    if (!validateForm('register-form')) return;
    
    // Show loading spinner
    const submitBtn = this.querySelector('button[type="submit"]');
    const spinner = submitBtn.querySelector('.spinner');
    const buttonText = submitBtn.querySelector('.button-text');
    
    buttonText.style.display = 'none';
    spinner.style.display = 'block';
    
    // Simulate API call
    setTimeout(() => {
        // Hide loading spinner
        buttonText.style.display = 'inline';
        spinner.style.display = 'none';
        
        // Close modal
        closeModal(registerModal);
        
        // Show success message (in a real app, you'd handle the registration response)
        alert('Registration successful! Please check your email to verify your account.');
    }, 1500);
});

document.getElementById('trip-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    if (!validateForm('trip-form')) return;
    
    // Show loading spinner
    const submitBtn = this.querySelector('button[type="submit"]');
    const spinner = submitBtn.querySelector('.spinner');
    const buttonText = submitBtn.querySelector('.button-text');
    
    buttonText.style.display = 'none';
    spinner.style.display = 'block';
    
    // Simulate payment processing
    setTimeout(() => {
        // Hide loading spinner
        buttonText.style.display = 'inline';
        spinner.style.display = 'none';
        
        // Get form values
        const tripName = document.getElementById('trip-name').value;
        const destination = document.getElementById('trip-destination').value;
        const startDate = document.getElementById('trip-start-date').value;
        const endDate = document.getElementById('trip-end-date').value;
        const groupSize = document.getElementById('trip-group-size').value;
        const plan = document.querySelector('input[name="trip-plan"]:checked').value;
        const paymentMethod = document.querySelector('.payment-method.active').getAttribute('data-method');
        
        // Format dates for display
        const formattedStartDate = new Date(startDate).toLocaleDateString('en-US', { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
        });
        const formattedEndDate = new Date(endDate).toLocaleDateString('en-US', { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
        });
        
        // Format plan name
        const planName = plan === 'free' ? 'Free Plan' : 'Premium Plan';
        
        // Format payment method
        let paymentText = '';
        switch(paymentMethod) {
            case 'credit-card':
                paymentText = 'Credit Card ending in ' + document.getElementById('card-number').value.slice(-4);
                break;
            case 'paypal':
                paymentText = 'PayPal';
                break;
            case 'bank-transfer':
                paymentText = 'Bank Transfer';
                break;
        }
        
        // Generate random confirmation number
        const confirmationNumber = Math.floor(100000 + Math.random() * 900000);
        
        // Set confirmation details
        document.getElementById('conf-trip-name').textContent = tripName;
        document.getElementById('conf-destination').textContent = destination;
        document.getElementById('conf-dates').textContent = ${formattedStartDate} - ${formattedEndDate};
        document.getElementById('conf-group-size').textContent = groupSize;
        document.getElementById('conf-plan').textContent = planName;
        document.getElementById('conf-payment-method').textContent = paymentText;
        document.getElementById('confirmation-number').textContent = confirmationNumber;
        
        // Show confirmation and hide form
        document.getElementById('trip-form-section').style.display = 'none';
        document.getElementById('booking-confirmation').style.display = 'block';
        
        // In a real app, you would send this data to your server here
        console.log('Trip booked:', {
            tripName,
            destination,
            startDate,
            endDate,
            groupSize,
            plan,
            paymentMethod,
            confirmationNumber
        });
    }, 2000);
});

// View trip button
viewTripBtn.addEventListener('click', function() {
    // Close the modal
    closeModal(tripModal);
    
    // Reset form for next use
    resetTripForm();
    
    // In a real app, you would redirect to the trip dashboard
    alert('In a real app, this would take you to your trip dashboard');
});

// Print confirmation button
printConfirmationBtn.addEventListener('click', function() {
    // In a real app, you would implement proper print styling
    window.print();
});

// Reset trip form
function resetTripForm() {
    document.getElementById('trip-form').reset();
    document.getElementById('trip-form-section').style.display = 'block';
    document.getElementById('booking-confirmation').style.display = 'none';
    
    // Reset payment method to default
    paymentMethods.forEach(m => m.classList.remove('active'));
    paymentMethods[0].classList.add('active');
    
    paymentForms.forEach(form => form.style.display = 'none');
    document.getElementById('credit-card-form').style.display = 'block';
    
    // Reset date pickers
    startDatePicker.clear();
    endDatePicker.clear();
    
    // Clear any error messages
    document.querySelectorAll('.error-message').forEach(el => {
        el.style.display = 'none';
    });
    
    document.querySelectorAll('.has-error').forEach(el => {
        el.classList.remove('has-error');
    });
}

// Smooth scrolling for navigation
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Testimonial carousel auto-scroll
const testimonialCards = document.querySelector('.testimonial-cards');
let scrollPosition = 0;
const cardWidth = 380 + 32; // card width + gap

function autoScrollTestimonials() {
    scrollPosition += cardWidth;
    if (scrollPosition > testimonialCards.scrollWidth - testimonialCards.clientWidth) {
        scrollPosition = 0;
    }
    testimonialCards.scrollTo({
        left: scrollPosition,
        behavior: 'smooth'
    });
}

// Scroll every 5 seconds
setInterval(autoScrollTestimonials, 5000);