const mongoose = require('mongoose');

const TripSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Please add a trip name']
  },
  description: {
    type: String
  },
  destination: {
    type: String,
    required: [true, 'Please add a destination']
  },
  startDate: {
    type: Date,
    required: [true, 'Please add a start date']
  },
  endDate: {
    type: Date,
    required: [true, 'Please add an end date']
  },
  groupSize: {
    type: String,
    enum: ['2-5', '6-10', '11-15', '16+'],
    required: [true, 'Please select group size']
  },
  plan: {
    type: String,
    enum: ['basic', 'premium', 'group'],
    required: [true, 'Please select a plan']
  },
  organizer: {
    type: mongoose.Schema.ObjectId,
    ref: 'User',
    required: true
  },
  members: [{
    user: {
      type: mongoose.Schema.ObjectId,
      ref: 'User'
    },
    role: {
      type: String,
      enum: ['admin', 'member'],
      default: 'member'
    },
    joinedAt: {
      type: Date,
      default: Date.now
    }
  }],
  expenses: [{
    type: mongoose.Schema.ObjectId,
    ref: 'Expense'
  }],
  activities: [{
    type: mongoose.Schema.ObjectId,
    ref: 'Activity'
  }],
  tasks: [{
    type: mongoose.Schema.ObjectId,
    ref: 'Task'
  }],
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Trip', TripSchema);