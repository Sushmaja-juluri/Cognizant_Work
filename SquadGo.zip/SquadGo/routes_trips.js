const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const auth = require('../middleware/auth');
const Trip = require('../models/Trip');
const User = require('../models/User');

// @route    POST api/v1/trips
// @desc     Create a new trip
// @access   Private
router.post(
  '/',
  [
    auth,
    [
      check('name', 'Trip name is required').not().isEmpty(),
      check('destination', 'Destination is required').not().isEmpty(),
      check('startDate', 'Start date is required').not().isEmpty(),
      check('endDate', 'End date is required').not().isEmpty(),
      check('groupSize', 'Group size is required').not().isEmpty(),
      check('plan', 'Plan is required').not().isEmpty()
    ]
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { name, description, destination, startDate, endDate, groupSize, plan } = req.body;

    try {
      const trip = new Trip({
        name,
        description,
        destination,
        startDate,
        endDate,
        groupSize,
        plan,
        organizer: req.user.id,
        members: [{
          user: req.user.id,
          role: 'admin'
        }]
      });

      await trip.save();

      // Add trip to user's trips array
      await User.findByIdAndUpdate(req.user.id, {
        $push: { trips: trip._id }
      });

      res.json(trip);
    } catch (err) {
      console.error(err.message);
      res.status(500).send('Server error');
    }
  }
);

// @route    GET api/v1/trips
// @desc     Get all trips for current user
// @access   Private
router.get('/', auth, async (req, res) => {
  try {
    const trips = await Trip.find({
      'members.user': req.user.id
    }).populate('organizer', 'name email')
      .populate('members.user', 'name email')
      .sort({ createdAt: -1 });

    res.json(trips);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// @route    GET api/v1/trips/:id
// @desc     Get trip by ID
// @access   Private
router.get('/:id', auth, async (req, res) => {
  try {
    const trip = await Trip.findById(req.params.id)
      .populate('organizer', 'name email')
      .populate('members.user', 'name email')
      .populate('expenses')
      .populate('activities')
      .populate('tasks');

    if (!trip) {
      return res.status(404).json({ msg: 'Trip not found' });
    }

    // Check if user is a member of the trip
    const isMember = trip.members.some(
      member => member.user._id.toString() === req.user.id
    );

    if (!isMember) {
      return res.status(401).json({ msg: 'Not authorized to access this trip' });
    }

    res.json(trip);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Trip not found' });
    }
    res.status(500).send('Server error');
  }
});

// @route    PUT api/v1/trips/:id
// @desc     Update trip
// @access   Private
router.put('/:id', auth, async (req, res) => {
  const { name, description, destination, startDate, endDate, groupSize, plan } = req.body;

  try {
    let trip = await Trip.findById(req.params.id);

    if (!trip) {
      return res.status(404).json({ msg: 'Trip not found' });
    }

    // Check if user is the organizer
    if (trip.organizer.toString() !== req.user.id) {
      return res.status(401).json({ msg: 'Not authorized to update this trip' });
    }

    trip = await Trip.findByIdAndUpdate(
      req.params.id,
      { $set: { name, description, destination, startDate, endDate, groupSize, plan } },
      { new: true }
    );

    res.json(trip);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Trip not found' });
    }
    res.status(500).send('Server error');
  }
});

// @route    DELETE api/v1/trips/:id
// @desc     Delete trip
// @access   Private
router.delete('/:id', auth, async (req, res) => {
  try {
    const trip = await Trip.findById(req.params.id);

    if (!trip) {
      return res.status(404).json({ msg: 'Trip not found' });
    }

    // Check if user is the organizer
    if (trip.organizer.toString() !== req.user.id) {
      return res.status(401).json({ msg: 'Not authorized to delete this trip' });
    }

    await trip.remove();

    // Remove trip from all members' trips array
    await User.updateMany(
      { trips: trip._id },
      { $pull: { trips: trip._id } }
    );

    res.json({ msg: 'Trip removed' });
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Trip not found' });
    }
    res.status(500).send('Server error');
  }
});

// @route    POST api/v1/trips/:id/invite
// @desc     Invite user to trip
// @access   Private
router.post('/:id/invite', auth, async (req, res) => {
  try {
    const trip = await Trip.findById(req.params.id);
    const { email } = req.body;

    if (!trip) {
      return res.status(404).json({ msg: 'Trip not found' });
    }

    // Check if user is a member with admin role
    const isAdmin = trip.members.some(
      member => member.user.toString() === req.user.id && member.role === 'admin'
    );

    if (!isAdmin) {
      return res.status(401).json({ msg: 'Not authorized to invite to this trip' });
    }

    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({ msg: 'User not found' });
    }

    // Check if user is already a member
    const isMember = trip.members.some(
      member => member.user.toString() === user._id.toString()
    );

    if (isMember) {
      return res.status(400).json({ msg: 'User is already a member of this trip' });
    }

    // Add user to trip members
    trip.members.push({
      user: user._id,
      role: 'member'
    });

    await trip.save();

    // Add trip to user's trips array
    await User.findByIdAndUpdate(user._id, {
      $push: { trips: trip._id }
    });

    res.json(trip);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Trip not found' });
    }
    res.status(500).send('Server error');
  }
});

module.exports = router;